CREATE FUNCTION getTotalAppointmentSinceFirstUnlockedNote(scEmpId INT, firstUnlockDate DATETIME)
  RETURNS INT
  BEGIN
DECLARE total_appointment INT(11);
SELECT count(*) into total_appointment FROM `cronCreatedForCacheUsedByEventsReport` WHERE `eventTypeName` = 'Appointment' and eventStatusName = 'Step 4: Approved by doc' and scEmployeeUID=scEmpId and eventEndDateTime>=firstUnlockDate;

RETURN total_appointment;
END;

