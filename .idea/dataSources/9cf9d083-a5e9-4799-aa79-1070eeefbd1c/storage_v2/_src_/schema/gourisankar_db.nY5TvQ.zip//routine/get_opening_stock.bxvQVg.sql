CREATE FUNCTION get_opening_stock(p_id INT, opening_date DATE)
  RETURNS DOUBLE
  BEGIN
	DECLARE op_balance DOUBLE;
  select (select opening_balance from product where product.product_id = p_id)+sum(inward)
-sum(outward) into op_balance
from stock_transaction
where stock_transaction.product_id=p_id and date(transaction_date)<opening_date; 

  IF op_balance is not null then
    RETURN op_balance;
 else
    RETURN 0;
  end if;
END;

