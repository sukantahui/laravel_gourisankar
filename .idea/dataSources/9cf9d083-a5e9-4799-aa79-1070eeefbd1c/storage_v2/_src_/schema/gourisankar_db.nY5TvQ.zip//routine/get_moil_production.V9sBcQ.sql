CREATE FUNCTION get_moil_production(opening_date DATE)
  RETURNS DOUBLE
  BEGIN
	DECLARE moil DOUBLE;
  select sum(inward) into moil
from stock_production_details where stock_production_master_id in 
(select stock_production_master_id from stock_transaction where product_id=1 and date(transaction_date)=opening_date and outward>0)
and product_id=3 group by product_id;

IF moil is not null then
    RETURN moil;
 else
    RETURN 0;
  end if;
	
END;

